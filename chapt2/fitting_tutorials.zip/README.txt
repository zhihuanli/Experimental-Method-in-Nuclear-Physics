ROOT Fit / RooFit 课堂实例（已在 ROOT 6.40.02 验证）

1. 解压整个运行包，保留 data/ 文件夹，与代码放在同一目录。
2. 在该目录运行 C++ 宏：
   root -l -b -q ROOT_Fit_Tutorial.C
   root -l -b -q RooFit_Tutorial.C
   root -l -b -q ML_Fit_Comparison.C
   root -l -b -q Weighted_Fit_Uncertainty.C
3. 或在 Jupyter 打开任一 notebook，选择能 import ROOT 的 Python kernel，
   从上到下运行所有单元。图片位于 fit_figures/；两份入门教程还会保存 ROOT 结果文件。
4. 分步讲义：
   https://zhihuanli.github.io/Experimental-Method-in-Nuclear-Physics/chapt2/ROOT_Fit_Tutorial.html
   https://zhihuanli.github.io/Experimental-Method-in-Nuclear-Physics/chapt2/RooFit%20mini%20tutorial.html
5. 专题查阅：ML_fit.ipynb 比较同一寿命样本的几种拟合方法；
   linearfit_error band.ipynb 逐步计算加权直线拟合与误差传播。

signal + background 使用讲义中的同一份固定 600 事件数据。
其余入门例子保留各自明确给定的教学模拟样本。
