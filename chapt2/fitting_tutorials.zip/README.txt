ROOT Fit / RooFit 课堂实例（已在 ROOT 6.40.02 验证）

1. 解压整个运行包，保留 data/ 文件夹，与代码放在同一目录。
2. 在该目录运行 C++ 宏：
   root -l -b -q ROOT_Fit_Tutorial.C
   root -l -b -q RooFit_Tutorial.C
3. 或在 Jupyter 打开任一 notebook，选择能 import ROOT 的 Python kernel，
   从上到下运行所有单元。输出的图片在 fit_figures/，拟合结果保存在 ROOT 文件中。
4. 分步讲义：
   https://zhihuanli.github.io/Experimental-Method-in-Nuclear-Physics/chapt2/ROOT_Fit_Tutorial.html
   https://zhihuanli.github.io/Experimental-Method-in-Nuclear-Physics/chapt2/RooFit%20mini%20tutorial.html

signal + background 使用讲义中的同一份固定 600 事件数据。
其余入门例子保留各自明确给定的教学模拟样本。
